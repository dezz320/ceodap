const activeControllers = new Map();
let globalTimeout = null;

function createController(userInfo) {
  stopController(userInfo.id);

  const controller = new AbortController();
  controller.meta = {
    chatId: userInfo.chatId,
    formattedNumber: userInfo.formattedNumber
  };

  activeControllers.set(userInfo.id, controller);
  return controller;
}

function getController(userId) {
  return activeControllers.get(userId);
}

function stopController(userId, bot = null, reason = "✘ Serangan telah dihentikan.") {
  const controller = activeControllers.get(userId);
  if (controller) {
    controller.abort();

    if (bot && controller.meta?.chatId && controller.meta?.formattedNumber) {
      bot.sendMessage(controller.meta.chatId, `${reason} Target: ${controller.meta.formattedNumber}`);
    }
  }
  activeControllers.delete(userId);
}

function stopAllControllers(bot = null, reason = "✘ Semua serangan dihentikan karena waktu habis.") {
  for (const [userId, controller] of activeControllers) {
    controller.abort();

    if (bot && controller.meta?.chatId && controller.meta?.formattedNumber) {
      bot.sendMessage(controller.meta.chatId, `${reason} Target: ${controller.meta.formattedNumber}`);
    }
  }

  activeControllers.clear();

  if (globalTimeout) clearTimeout(globalTimeout);
  globalTimeout = null;
}

function startGlobalTimeout(durationMs = 60000, bot = null) {
  if (globalTimeout) clearTimeout(globalTimeout);

  globalTimeout = setTimeout(() => {
    console.log("✘ Waktu habis: Semua serangan Otax dihentikan otomatis.");
    stopAllControllers(bot, "✘ Serangan Otax dihentikan otomatis karena waktu habis.");
  }, durationMs);

  console.log(`✘ Serangan Otax dimulai selama ${durationMs / 1000} detik.`);
}

module.exports = {
  createController,
  getController,
  stopController,
  stopAllControllers,
  startGlobalTimeout
};