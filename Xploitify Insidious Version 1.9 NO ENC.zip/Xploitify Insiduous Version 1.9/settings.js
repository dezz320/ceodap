
const settings = {
  OWNER_URL: "https://t.me/susudancow15", //ganti Otapengenkawin dengan username tele lu
};
//ganti bagian dalam '...' saja
module.exports = settings;