module.exports = {
  BOT_TOKEN: "7792608786:AAFzgT2fwJAjcH9RVUTck3SY0dXctto5pug",//bot tokenlu
  OWNER_ID: ["5640453720"],//id lu
};
//BY DAPA