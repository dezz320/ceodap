const { BOT_TOKEN } = require("../../config.js");
async function ReactMsg(chatId, messageId, emoji) {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/setMessageReaction`;
  const body = {
    chat_id: chatId,
    message_id: messageId,
    reaction: [{ type: "emoji", emoji }],
    is_big: true
  };
   await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
}


module.exports = { ReactMsg }